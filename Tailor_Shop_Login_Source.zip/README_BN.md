# Tailor Shop — Login সহ দুইটি Flutter অ্যাপ

এই ZIP-এ আলাদা Customer ও Admin Flutter app-এর source code আছে।

## Customer App
- Email/password দিয়ে Sign Up ও Login
- লগআউট
- দোকানের ডিজাইন বা নিজের ডিজাইন বেছে গ্যালারি থেকে ছবি আপলোড
- বুক, লম্বা, কাঁধ, হাতা, হাতার মুখ, কোমর, গলার মাপ
- ইঞ্চি/সেন্টিমিটার
- নাম, ফোন, ঠিকানা দিয়ে অর্ডার

## Admin App
- Admin email/password login
- Admin email allowlist check (কোডে `adminEmail` পরিবর্তন করতে হবে)
- অর্ডার, ছবি ও মাপ দেখা
- Accept/Reject/Processing/Ready/Delivered
- Delivery date
- Logout

## সেটআপ জরুরি
এটি source code starter, APK নয়। Firebase project configure না করলে login বা order কাজ করবে না।

1. Flutter SDK + Android Studio ইনস্টল করুন।
2. Firebase Console-এ project তৈরি করুন।
3. Authentication > Sign-in method থেকে Email/Password enable করুন।
4. Firestore Database ও Storage চালু করুন।
5. Firebase-এ দুটি Android app register করুন এবং `google-services.json` প্রতিটি app-এর `android/app/` ফোল্ডারে রাখুন।
6. প্রতিটি app-এর root-এ চালান: `flutter pub get`
7. `flutterfire configure` চালিয়ে `firebase_options.dart` তৈরি করুন। এরপর `main.dart`-এ `await Firebase.initializeApp();` বদলে নিচের কোড ব্যবহার করুন:
   `await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);`
   এবং `import 'firebase_options.dart';` যোগ করুন।
8. Admin Firebase Authentication-এ admin email/password account manually create করুন। `admin_app/lib/main.dart`-এ `adminEmail`-এ ওই email বসান। Admin app-এ public sign-up নেই।
9. `flutter run` দিয়ে পরীক্ষা করুন। APK: `flutter build apk --release`

## নিরাপত্তা
শুধু app-এর UI-তে admin email check যথেষ্ট নিরাপত্তা নয়। Production-এ Firestore/Storage Security Rules এবং Firebase Admin custom claims বা server-verified admin role বাধ্যতামূলক করুন। Customer যেন অন্যের অর্ডার পড়তে বা update করতে না পারে; status/deliveryDate শুধু server-verified admin বদলাতে পারবে। Rules configure না করে production-এ ব্যবহার করবেন না।

## Push notification
এ সংস্করণে authentication ও order data আছে, কিন্তু push notification এখনো নেই। Firebase Cloud Messaging + trusted Cloud Functions backend দিয়ে admin status change হলে customer device-এ notification পাঠাতে হবে।
