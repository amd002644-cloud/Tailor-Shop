import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:image_picker/image_picker.dart';
import 'package:flutter/material.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(const TailorCustomerApp());
}

class TailorCustomerApp extends StatelessWidget {
  const TailorCustomerApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'Tailor Shop Customer',
    theme: ThemeData(colorSchemeSeed: const Color(0xff245b50), useMaterial3: true),
    home: const AuthGate(),
  );
}

class AuthGate extends StatelessWidget {
  const AuthGate({super.key});
  @override
  Widget build(BuildContext context) => StreamBuilder<User?>(
    stream: FirebaseAuth.instance.authStateChanges(),
    builder: (context, snap) {
      if (snap.connectionState == ConnectionState.waiting) return const Scaffold(body: Center(child: CircularProgressIndicator()));
      return snap.data == null ? const CustomerLoginPage() : const OrderPage();
    },
  );
}

class CustomerLoginPage extends StatefulWidget {
  const CustomerLoginPage({super.key});
  @override
  State<CustomerLoginPage> createState() => _CustomerLoginPageState();
}

class _CustomerLoginPageState extends State<CustomerLoginPage> {
  final email = TextEditingController(), password = TextEditingController(), name = TextEditingController();
  bool register = false, busy = false;
  String? error;
  Future<void> submit() async {
    setState(() { busy = true; error = null; });
    try {
      if (register) {
        final cred = await FirebaseAuth.instance.createUserWithEmailAndPassword(email: email.text.trim(), password: password.text);
        await cred.user?.updateDisplayName(name.text.trim());
      } else {
        await FirebaseAuth.instance.signInWithEmailAndPassword(email: email.text.trim(), password: password.text);
      }
    } on FirebaseAuthException catch (e) {
      setState(() => error = e.message ?? e.code);
    } catch (e) { setState(() => error = e.toString()); }
    finally { if (mounted) setState(() => busy = false); }
  }
  @override
  Widget build(BuildContext context) => Scaffold(
    body: Center(child: SingleChildScrollView(padding: const EdgeInsets.all(24), child: ConstrainedBox(
      constraints: const BoxConstraints(maxWidth: 420), child: Card(child: Padding(padding: const EdgeInsets.all(22), child: Column(
        mainAxisSize: MainAxisSize.min, children: [
          const Icon(Icons.content_cut, size: 52, color: Color(0xff245b50)),
          const SizedBox(height: 8),
          const Text('TAILOR SHOP', style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold)),
          Text(register ? 'নতুন কাস্টমার অ্যাকাউন্ট খুলুন' : 'কাস্টমার লগইন'),
          const SizedBox(height: 18),
          if (register) TextField(controller: name, decoration: const InputDecoration(labelText: 'আপনার নাম', prefixIcon: Icon(Icons.person))),
          TextField(controller: email, keyboardType: TextInputType.emailAddress, decoration: const InputDecoration(labelText: 'ইমেইল', prefixIcon: Icon(Icons.email))),
          TextField(controller: password, obscureText: true, decoration: const InputDecoration(labelText: 'পাসওয়ার্ড (কমপক্ষে ৬ অক্ষর)', prefixIcon: Icon(Icons.lock))),
          if (error != null) Padding(padding: const EdgeInsets.only(top: 10), child: Text(error!, style: const TextStyle(color: Colors.red))),
          const SizedBox(height: 16),
          SizedBox(width: double.infinity, child: FilledButton(onPressed: busy ? null : submit, child: Text(busy ? 'অপেক্ষা করুন...' : register ? 'অ্যাকাউন্ট তৈরি করুন' : 'লগইন করুন'))),
          TextButton(onPressed: busy ? null : () => setState(() { register = !register; error = null; }), child: Text(register ? 'আগে অ্যাকাউন্ট আছে? লগইন' : 'নতুন কাস্টমার? অ্যাকাউন্ট খুলুন')),
        ],
      ))),
    ))),
  );
}

class OrderPage extends StatefulWidget {
  const OrderPage({super.key});
  @override
  State<OrderPage> createState() => _OrderPageState();
}

class _OrderPageState extends State<OrderPage> {
  final formKey = GlobalKey<FormState>();
  final name = TextEditingController(), phone = TextEditingController(), address = TextEditingController();
  final fields = ['বুকের মাপ', 'জামার লম্বা', 'কাঁধ', 'হাতার লম্বা', 'হাতার মুখ', 'কোমর', 'গলা'];
  final measurements = <String, TextEditingController>{};
  String unit = 'ইঞ্চি', designType = 'দোকানের ডিজাইন';
  XFile? photo;
  bool sending = false;
  @override
  void initState() { super.initState(); for (final f in fields) { measurements[f] = TextEditingController(); } }
  Future<void> choosePhoto() async {
    final x = await ImagePicker().pickImage(source: ImageSource.gallery, imageQuality: 82);
    if (x != null) setState(() => photo = x);
  }
  Future<void> submit() async {
    if (!formKey.currentState!.validate()) return;
    if (photo == null) { ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('জামার ডিজাইনের ছবি নির্বাচন করুন'))); return; }
    setState(() => sending = true);
    try {
      final user = FirebaseAuth.instance.currentUser!;
      final id = DateTime.now().millisecondsSinceEpoch.toString();
      final ref = FirebaseStorage.instance.ref('order_designs/${user.uid}/$id.jpg');
      await ref.putFile(File(photo!.path));
      final imageUrl = await ref.getDownloadURL();
      await FirebaseFirestore.instance.collection('orders').doc(id).set({
        'customerUid': user.uid, 'customerEmail': user.email,
        'customerName': name.text.trim(), 'phone': phone.text.trim(), 'address': address.text.trim(),
        'designType': designType, 'imageUrl': imageUrl, 'unit': unit,
        'measurements': {for (final f in fields) f: measurements[f]!.text.trim()},
        'status': 'New Order', 'deliveryDate': '', 'createdAt': FieldValue.serverTimestamp(),
      });
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('অর্ডার জমা হয়েছে!')));
      formKey.currentState!.reset(); name.clear(); phone.clear(); address.clear();
      for (final c in measurements.values) { c.clear(); }
      setState(() { photo = null; designType = 'দোকানের ডিজাইন'; unit = 'ইঞ্চি'; });
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('অর্ডার জমা হয়নি: $e')));
    } finally { if (mounted) setState(() => sending = false); }
  }
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Tailor Shop'), actions: [IconButton(tooltip: 'লগআউট', onPressed: () => FirebaseAuth.instance.signOut(), icon: const Icon(Icons.logout))]),
    body: Form(key: formKey, child: ListView(padding: const EdgeInsets.all(16), children: [
      const Text('জামার ডিজাইন নির্বাচন করুন', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
      const SizedBox(height: 10),
      SegmentedButton<String>(segments: const [ButtonSegment(value: 'দোকানের ডিজাইন', label: Text('দোকানের ডিজাইন')), ButtonSegment(value: 'নিজের ডিজাইন', label: Text('নিজের ডিজাইন'))], selected: {designType}, onSelectionChanged: (s) => setState(() => designType = s.first)),
      OutlinedButton.icon(onPressed: choosePhoto, icon: const Icon(Icons.upload_file), label: const Text('গ্যালারি থেকে জামার ছবি আপলোড করুন')),
      if (photo != null) Padding(padding: const EdgeInsets.symmetric(vertical: 8), child: Image.file(File(photo!.path), height: 190, fit: BoxFit.contain)),
      const Divider(height: 28),
      const Text('আপনার জামার মাপ', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
      DropdownButtonFormField<String>(value: unit, decoration: const InputDecoration(labelText: 'মাপের একক'), items: const [DropdownMenuItem(value: 'ইঞ্চি', child: Text('ইঞ্চি')), DropdownMenuItem(value: 'সেন্টিমিটার', child: Text('সেন্টিমিটার'))], onChanged: (v) => setState(() => unit = v!)),
      ...fields.map((f) => TextFormField(controller: measurements[f], keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: InputDecoration(labelText: '$f ($unit)'), validator: (v) => v == null || v.trim().isEmpty ? 'মাপ লিখুন' : null)),
      const Divider(height: 28),
      const Text('কাস্টমারের তথ্য', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
      TextFormField(controller: name, decoration: const InputDecoration(labelText: 'নাম'), validator: required),
      TextFormField(controller: phone, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'মোবাইল নম্বর'), validator: required),
      TextFormField(controller: address, maxLines: 3, decoration: const InputDecoration(labelText: 'সম্পূর্ণ ঠিকানা'), validator: required),
      const SizedBox(height: 18),
      FilledButton(onPressed: sending ? null : submit, child: Text(sending ? 'জমা হচ্ছে...' : 'অর্ডার সাবমিট করুন')),
    ])),
  );
  String? required(String? v) => v == null || v.trim().isEmpty ? 'এই তথ্যটি দিন' : null;
}
