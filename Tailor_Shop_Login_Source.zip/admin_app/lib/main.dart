import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';

// Replace this with the exact email of the shop owner/admin account.
// Create this account in Firebase Authentication first.
const String adminEmail = 'admin@example.com';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(const TailorAdminApp());
}

class TailorAdminApp extends StatelessWidget {
  const TailorAdminApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false, title: 'Tailor Shop Admin',
    theme: ThemeData(colorSchemeSeed: const Color(0xff245b50), useMaterial3: true),
    home: const AdminGate(),
  );
}

class AdminGate extends StatelessWidget {
  const AdminGate({super.key});
  @override
  Widget build(BuildContext context) => StreamBuilder<User?>(
    stream: FirebaseAuth.instance.authStateChanges(),
    builder: (context, snap) {
      if (snap.connectionState == ConnectionState.waiting) return const Scaffold(body: Center(child: CircularProgressIndicator()));
      final user = snap.data;
      if (user == null) return const AdminLoginPage();
      if ((user.email ?? '').toLowerCase() != adminEmail.toLowerCase()) {
        FirebaseAuth.instance.signOut();
        return const Scaffold(body: Center(child: Text('এই অ্যাকাউন্টের Admin অনুমতি নেই।')));
      }
      return const OrdersPage();
    },
  );
}

class AdminLoginPage extends StatefulWidget {
  const AdminLoginPage({super.key});
  @override
  State<AdminLoginPage> createState() => _AdminLoginPageState();
}
class _AdminLoginPageState extends State<AdminLoginPage> {
  final email = TextEditingController(), password = TextEditingController();
  bool busy = false;
  String? error;
  Future<void> login() async {
    setState(() { busy = true; error = null; });
    try {
      await FirebaseAuth.instance.signInWithEmailAndPassword(email: email.text.trim(), password: password.text);
      if ((FirebaseAuth.instance.currentUser?.email ?? '').toLowerCase() != adminEmail.toLowerCase()) {
        await FirebaseAuth.instance.signOut();
        setState(() => error = 'এই ইমেইলটি Admin হিসেবে অনুমোদিত নয়।');
      }
    } on FirebaseAuthException catch (e) { setState(() => error = e.message ?? e.code); }
    catch (e) { setState(() => error = e.toString()); }
    finally { if (mounted) setState(() => busy = false); }
  }
  @override
  Widget build(BuildContext context) => Scaffold(
    body: Center(child: SingleChildScrollView(padding: const EdgeInsets.all(24), child: ConstrainedBox(
      constraints: const BoxConstraints(maxWidth: 420), child: Card(child: Padding(padding: const EdgeInsets.all(22), child: Column(mainAxisSize: MainAxisSize.min, children: [
        const Icon(Icons.admin_panel_settings, size: 54, color: Color(0xff245b50)),
        const Text('TAILOR SHOP ADMIN', style: TextStyle(fontSize: 23, fontWeight: FontWeight.bold)),
        const Text('শুধু দোকানদারের জন্য লগইন'),
        const SizedBox(height: 18),
        TextField(controller: email, keyboardType: TextInputType.emailAddress, decoration: const InputDecoration(labelText: 'Admin ইমেইল', prefixIcon: Icon(Icons.email))),
        TextField(controller: password, obscureText: true, decoration: const InputDecoration(labelText: 'পাসওয়ার্ড', prefixIcon: Icon(Icons.lock))),
        if (error != null) Padding(padding: const EdgeInsets.only(top: 10), child: Text(error!, style: const TextStyle(color: Colors.red))),
        const SizedBox(height: 16),
        SizedBox(width: double.infinity, child: FilledButton(onPressed: busy ? null : login, child: Text(busy ? 'লগইন হচ্ছে...' : 'Admin লগইন'))),
      ]))),
    ))),
  );
}

class OrdersPage extends StatelessWidget {
  const OrdersPage({super.key});
  Future<void> updateOrder(BuildContext context, String id, String status, String date) async {
    await FirebaseFirestore.instance.collection('orders').doc(id).update({'status': status, 'deliveryDate': date, 'updatedAt': FieldValue.serverTimestamp()});
    if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('অর্ডার আপডেট হয়েছে')));
  }
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Tailor Shop Admin'), actions: [IconButton(onPressed: () => FirebaseAuth.instance.signOut(), icon: const Icon(Icons.logout))]),
    body: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
      stream: FirebaseFirestore.instance.collection('orders').orderBy('createdAt', descending: true).snapshots(),
      builder: (context, snap) {
        if (snap.hasError) return Center(child: Text('সমস্যা: ${snap.error}'));
        if (!snap.hasData) return const Center(child: CircularProgressIndicator());
        final docs = snap.data!.docs;
        if (docs.isEmpty) return const Center(child: Text('এখনো কোনো অর্ডার আসেনি'));
        return ListView.builder(padding: const EdgeInsets.all(12), itemCount: docs.length, itemBuilder: (context, i) {
          final doc = docs[i], d = doc.data(), m = Map<String, dynamic>.from(d['measurements'] ?? {});
          return Card(margin: const EdgeInsets.only(bottom: 12), child: Padding(padding: const EdgeInsets.all(12), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [Expanded(child: Text('অর্ডার #${doc.id}', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 17))), Chip(label: Text('${d['status'] ?? 'New Order'}'))]),
            if ((d['imageUrl'] ?? '').toString().isNotEmpty) ClipRRect(borderRadius: BorderRadius.circular(8), child: Image.network(d['imageUrl'], height: 180, width: double.infinity, fit: BoxFit.contain)),
            Text('নাম: ${d['customerName'] ?? ''}'), Text('ফোন: ${d['phone'] ?? ''}'), Text('ঠিকানা: ${d['address'] ?? ''}'),
            Text('ইমেইল: ${d['customerEmail'] ?? ''}'), Text('মাপ (${d['unit'] ?? ''}): ${m.entries.map((e) => '${e.key}: ${e.value}').join(' | ')}'),
            Text('ডেলিভারি: ${d['deliveryDate']?.toString().isEmpty ?? true ? 'তারিখ দেওয়া হয়নি' : d['deliveryDate']}'),
            Wrap(spacing: 6, children: [
              OutlinedButton(onPressed: () => updateOrder(context, doc.id, 'Accepted', (d['deliveryDate'] ?? '').toString()), child: const Text('Accept')),
              OutlinedButton(onPressed: () => updateOrder(context, doc.id, 'Rejected', (d['deliveryDate'] ?? '').toString()), child: const Text('Reject')),
              OutlinedButton(onPressed: () => updateOrder(context, doc.id, 'Processing', (d['deliveryDate'] ?? '').toString()), child: const Text('Processing')),
              OutlinedButton(onPressed: () => updateOrder(context, doc.id, 'Ready', (d['deliveryDate'] ?? '').toString()), child: const Text('Ready')),
              OutlinedButton(onPressed: () => updateOrder(context, doc.id, 'Delivered', (d['deliveryDate'] ?? '').toString()), child: const Text('Delivered')),
            ]),
            Align(alignment: Alignment.centerRight, child: TextButton.icon(onPressed: () async {
              final picked = await showDatePicker(context: context, firstDate: DateTime.now(), lastDate: DateTime.now().add(const Duration(days: 365)), initialDate: DateTime.now().add(const Duration(days: 3)));
              if (picked != null) {
                final date = '${picked.year}-${picked.month.toString().padLeft(2, '0')}-${picked.day.toString().padLeft(2, '0')}';
                await updateOrder(context, doc.id, (d['status'] ?? 'Accepted').toString(), date);
              }
            }, icon: const Icon(Icons.calendar_month), label: const Text('ডেলিভারি তারিখ দিন'))),
          ])));
        });
      },
    ),
  );
}
